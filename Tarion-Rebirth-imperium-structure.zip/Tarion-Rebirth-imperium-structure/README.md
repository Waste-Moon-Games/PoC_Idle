# Tarion-Rebirth

Tarion Rebirth - This is a game inspired by such works as Darkest Dungeon (atmosphere) and Invincible (story), in the genre of 2D management with role-playing elements. 

The player controls the Tarion people, a powerful military race trying to rebuild their Empire after the Blood Wrath virus wiped out most of the population. The game is built around the choice of missions, castes, heroes and their development. The player will have to decide which planets to capture, which heroes to send, and how to deal with the defeated: cruelly or diplomatically.
