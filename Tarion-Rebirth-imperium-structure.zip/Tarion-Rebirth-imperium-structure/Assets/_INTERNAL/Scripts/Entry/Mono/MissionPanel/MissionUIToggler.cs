﻿using UI.Base;

namespace Entry.Mono.MissionPanel
{
    public class MissionUIToggler : SimpleWindowToggler
    {
    }
}