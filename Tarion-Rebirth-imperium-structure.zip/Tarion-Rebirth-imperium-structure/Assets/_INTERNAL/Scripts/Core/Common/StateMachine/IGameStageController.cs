﻿using Core.Factories;

namespace StateMachine.Base
{
    public interface IGameStageController
    {
        int ControllerId { get; }
        IStageFactory StageFactory { get; }
        void StartCycle();
        void Update();
        void SetStage(IStage newStage);
        void EndCycle();
        void ForceEnd();
    }
}