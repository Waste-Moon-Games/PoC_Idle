﻿namespace Core.Common.Instances
{
    public interface IInstance
    {
        float CalculatePower();
    }
}