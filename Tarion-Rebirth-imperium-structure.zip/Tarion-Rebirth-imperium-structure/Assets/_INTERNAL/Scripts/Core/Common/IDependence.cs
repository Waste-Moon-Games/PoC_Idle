﻿namespace Core.Common
{
    public interface IDependence
    {
    }
}