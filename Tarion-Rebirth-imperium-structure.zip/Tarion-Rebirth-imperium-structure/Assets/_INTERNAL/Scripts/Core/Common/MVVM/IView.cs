﻿namespace Core.Common.MVVM
{
    public interface IView
    {
        void BindViewModel(IViewModel viewModel);
    }
}