﻿namespace Core.Common.MVVM
{
    public interface IModel
    {
    }
}