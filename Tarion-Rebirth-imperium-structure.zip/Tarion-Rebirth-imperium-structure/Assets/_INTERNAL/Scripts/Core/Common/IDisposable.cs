﻿namespace Core.Common
{
    public interface IDisposable
    {
        void Dispose();
    }
}