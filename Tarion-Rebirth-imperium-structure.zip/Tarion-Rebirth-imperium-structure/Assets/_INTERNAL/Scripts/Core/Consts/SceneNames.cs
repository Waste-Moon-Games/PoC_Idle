namespace Core.Consts
{
    public static class SceneNames
    {
        public const string BOOT = "Start";
        public const string MAIN_MENU = "Main";
        public const string HEROS_MENU = "HeroMenuScene";
        public const string GALAXY_MAP = "MapScene";
    }
}