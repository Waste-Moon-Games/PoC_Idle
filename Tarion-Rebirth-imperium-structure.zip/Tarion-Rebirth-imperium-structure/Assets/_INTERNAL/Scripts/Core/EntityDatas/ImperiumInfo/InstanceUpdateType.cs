﻿namespace Core.EntityDatas.ImperiumInfo
{
    public enum InstanceUpdateType
    {
        HeroCount, PlanetCount, MaxHeroCount, MaxPlanetCount
    }
}