﻿namespace GameEntity.Planet
{
    public enum PlanetType
    {
        Industrial,
        Research,
        Military,
        Capital,
        Colony
    }
}