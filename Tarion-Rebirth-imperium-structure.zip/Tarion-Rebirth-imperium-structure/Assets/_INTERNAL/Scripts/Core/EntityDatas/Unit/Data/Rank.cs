﻿namespace GameEntity.Unit.Data
{
    public enum Rank
    {
        Recruit,
        Veteran,
        Elite,
        Champion,
        Guardian
    }
}
