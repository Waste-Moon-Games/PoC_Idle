﻿namespace Core.EntityDatas.Unit.Data
{
    public enum HeroGender
    {
        Male, Female
    }
}