﻿namespace Core.EntityDatas.Unit.Data
{
    public enum HeroQuality
    {
        Common, Uncommon, Rare, Epic, Legendary
    }
}