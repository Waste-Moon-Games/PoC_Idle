﻿namespace Core.EntityDatas.Unit.Data
{
    public enum HeroStatType
    {
        Strength, Dexterity, Intelligence
    }
}