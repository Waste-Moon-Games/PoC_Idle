﻿namespace GameEntity.Mission
{
    public enum MissionType
    {
        Force,
        Diplomacy,
        Sabotage,
        Recon
    }
}