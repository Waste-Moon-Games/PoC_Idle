﻿using System.ComponentModel;

namespace Core.EntityDatas.Resource
{
    public enum ResourceType
    {
        [Description("Void Matter")]
        Void_Matter,

        [Description("Minerals")]
        Mineral_Crystalls,

        [Description("Dark Energy")]
        Dark_Energy
    }
}