﻿using Core.Contex.Debug;
using GameEntity.DataInstance;
using GameEntity.Mission;
using Scripts.GameEntity.DataInstance;
using System;
using UnityEngine;

namespace Contex.MissionInfo
{
    public class MissionContex
    {
        [field: SerializeField] public PlanetInstance SelectedPlanet {  get; private set; }
        [field: SerializeField] public HeroInstance SelectedHero { get; private set; }
        [field: SerializeField] public MissionInstance PreparedMission { get; private set; }
        [field: SerializeField] public MissionType SelectedMissionType { get; private set; }
        [field: SerializeField] public MissionData CurrentMissionData { get; private set; }

        public event Action<PlanetInstance> OnPlanetSelected;
        public event Action<PlanetInstance> OnPlanetCaprured;
        public event Action<HeroInstance> OnHeroSelected;
        public event Action<MissionType> OnMissionTypeSelected;
        public event Action<MissionInstance> OnMissionPrepared;

        public event Action<float> OnMissionDifficultCalculated;
        public event Action<float> OnMissionDurationCalculated;
        public event Action<float> OnMissionSuccessChanceCalculated;

        public MissionContex()
        {
            CurrentMissionData = new();
        }

        public void SetPlanet(PlanetInstance selectedPlanet)
        {
            SelectedPlanet = selectedPlanet;
            CurrentMissionData.TargetPlanet = SelectedPlanet.RuntimeData;

            OnPlanetSelected?.Invoke(SelectedPlanet);

            DebugContex.SetPlanet(selectedPlanet);
        }

        public void SetHero(HeroInstance selectedHero)
        {
            SelectedHero = selectedHero;
            CurrentMissionData.ChosenHero = SelectedHero.RuntimeData;

            OnHeroSelected?.Invoke(SelectedHero);

            DebugContex.SetHero(selectedHero);
        }

        public void SetMissionType(MissionType selectedMissionType)
        {
            SelectedMissionType = selectedMissionType;
            CurrentMissionData.Type = SelectedMissionType;

            OnMissionTypeSelected?.Invoke(SelectedMissionType);
        }

        public void SetPreparedMission(MissionInstance missionInstance)
        {
            PreparedMission = missionInstance;

            OnMissionDifficultCalculated?.Invoke(missionInstance.Difficulty);
            OnMissionDurationCalculated?.Invoke(missionInstance.Duration);
            OnMissionSuccessChanceCalculated?.Invoke(missionInstance.SuccessChance);

            OnMissionPrepared?.Invoke(PreparedMission);
        }

        public MissionInstance TryCreateMissionInstane()
        {
            if (SelectedPlanet != null && SelectedHero != null)
                return new MissionInstance(CurrentMissionData, SelectedPlanet, SelectedHero);

            return null;
        }

        public void ApplyMissionResults()
        {
            if (PreparedMission == null)
                return;

            SelectedHero.AddExperience(PreparedMission.GainedExp);
            SelectedPlanet.SetPlanetStatus(PreparedMission.MissionSuccessful);

            if (PreparedMission.MissionSuccessful)
                OnPlanetCaprured?.Invoke(SelectedPlanet);

            SelectedPlanet.CalculatePower();

            PreparedMission = null;
        }
    }
}