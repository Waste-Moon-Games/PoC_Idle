﻿using Contex.MissionInfo;
using Core.Common;
using Entry.EntryData;
using GameEntity.DataInstance;
using StateMachine.Base;

namespace StateMachine.Stages
{
    public class MissionPreparationStage : IStage, IDisposable
    {
        private IGameStageController _controller;
        private MissionContex _missionContex;

        public MissionPreparationStage(IGameStageController controller, StageDependencies dependencies)
        {
            _controller = controller;
            _missionContex = dependencies.MissionContex;
        }

        public void Enter()
        {
            _missionContex.OnMissionPrepared += HandlePreparedMission;

            MissionInstance mission = _missionContex.TryCreateMissionInstane();

            mission?.PrepareMission();
            _missionContex.SetPreparedMission(mission);
        }

        public void RefreshDeps(IDependence _) { }

        public void Tick() { }

        public void Exit()
        {
            _missionContex.OnMissionPrepared -= HandlePreparedMission;
        }

        public void Dispose()
        {
            _controller = null;
            _missionContex = null;
        }

        private void HandlePreparedMission(MissionInstance _)
        {
            _missionContex?.SelectedHero?.SetBusyStatus(true);
            _missionContex?.SelectedPlanet?.SetBusyStatus(true);
            _controller.SetStage(_controller.StageFactory.CreateMissionExecutionStage(_controller));
        }
    }
}